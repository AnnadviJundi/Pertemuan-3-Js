// Variabel untuk masukkan nama
let nama = prompt('Nama Kamu Siapa?')

// Variabel kehadiran
let Hadir = prompt('Masukkan 1 jika hadir, masukkan 0 jika kamu bolos')

// Variabel cek
let cek = confirm("Kamu sudah hadir?")

// varibel cek kedua
let chek = confirm("Masak sih?")

// hasil kehadiran
let hasil = Hadir == 1 ? "Kamu sudah hadir kok" : "kamu belum hadir, Kemana?"


alert(hasil)